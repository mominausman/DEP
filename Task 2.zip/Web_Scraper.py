
import requests
from bs4 import BeautifulSoup
import csv

# web scrapping is actually fetching content of the website i have used "request" library for fetching. 
url = "https://www.example.com/products/phones"  # I have written an example url because of ethical scraping as many not but alot sites dont allow for web scraping

response = requests.get(url)
soup = BeautifulSoup(response.content, "html.parser")

products = soup.find_all("div", class_="product-item")  # Assuming(as its an example site) product items have this class

data = []  # List to store extracted data
for product in products:
    name = product.find("h3").text.strip()  # This Extract product name from <h3> tag
    price = product.find("span", class_="price").text.strip()  # This loc extract price from <span> with class "price"

    data.append([name, price])  # ad data to a list (representing a CSV row).

with open("products.csv", "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Product Name", "Price"])  # Write header row.
    writer.writerows(data)  # Write product data rows.

print("Data scraped and saved to products.csv")
